// Hent innloggingsBoks-elementet
const loginBoks = document.getElementById("login-boks");

// Hent innloggingslenke-elementet
const loginLink = document.getElementById("login-link");

// Hent lukkeknapp-elementet inne i innloggingsBoksen
const closeBoks = document.querySelector("#login-boks .close");

// Åpne innloggingsboksen når innloggingslenken blir klikket på
loginLink.addEventListener("click", function(event) {
  event.preventDefault();
  loginBoks.style.display = "block";
});

// Lukk innloggingsboksen når lukkeknappen blir klikket på
closeBoks.addEventListener("click", function() {
  loginBoks.style.display = "none";
});

// Lukk innloggingsBoksen når du klikker utenfor Boksen
window.addEventListener("click", function(event) {
  if (event.target === loginBoks) {
    loginBoks.style.display = "none";
  }
});

// Behandle skjemainnsendingen
const loginForm = document.getElementById("login-form");

loginForm.addEventListener("submit", function(event) {
  event.preventDefault();

  // Hent brukernavn- og passordet
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;


  // Testing om det funker med brukernavn admin og passord admin
  if (username === "admin" && password === "admin") {
    alert("Innlogging vellykket!");
    // Utfør handlinger om man logger inn
    // For eksempel, tar deg til hjemmesiden
    window.location.href = "index.html";
  } else {
    alert("Ugyldig brukernavn eller passord. Vennligst prøv igjen.");
  }

  // Tilbakestill alt
  loginForm.reset();
});